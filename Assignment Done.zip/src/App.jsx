// src/App.jsx
import React from 'react';
import { Provider } from 'react-redux';
import { configureStore } from '@reduxjs/toolkit';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { CssBaseline, Container, Typography, Box } from '@mui/material';
import TaskList from './components/TaskList';
import TaskForm from './components/TaskForm';
import FilterSort from './components/FilterSort';
import taskReducer from './features/slices/taskSlice';

const store = configureStore({
  reducer: {
    tasks: taskReducer,
  },
});

const theme = createTheme({
  palette: {
    mode: 'light',
  },
});

function App() {
  return (
    <Provider store={store}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Container maxWidth="md" sx={{ py: 4 }}>
          <Typography variant="h4" component="h1" gutterBottom align="center">
            Task Manager
          </Typography>
          <Box sx={{ mb: 4 }}>
            <TaskForm />
          </Box>
          <FilterSort />
          <TaskList />
        </Container>
      </ThemeProvider>
    </Provider>
  );
}

export default App;