// src/components/FilterSort.jsx
import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  Box,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  ToggleButton,
  ToggleButtonGroup,
} from '@mui/material';
import {
  setFilter,
  setSortBy,
  setSortDirection,
} from '../features/slices/taskSlice';

const FilterSort = () => {
  const dispatch = useDispatch();
  const { filter, sortBy, sortDirection } = useSelector((state) => state.tasks);

  return (
    <Box display="flex" gap={2} sx={{ mb: 2 }}>
      <FormControl size="small" sx={{ minWidth: 120 }}>
        <InputLabel>Filter</InputLabel>
        <Select
          value={filter}
          label="Filter"
          onChange={(e) => dispatch(setFilter(e.target.value))}
        >
          <MenuItem value="all">All</MenuItem>
          <MenuItem value="active">Active</MenuItem>
          <MenuItem value="completed">Completed</MenuItem>
        </Select>
      </FormControl>

      <FormControl size="small" sx={{ minWidth: 120 }}>
        <InputLabel>Sort By</InputLabel>
        <Select
          value={sortBy}
          label="Sort By"
          onChange={(e) => dispatch(setSortBy(e.target.value))}
        >
          <MenuItem value="date">Date</MenuItem>
          <MenuItem value="priority">Priority</MenuItem>
        </Select>
      </FormControl>

      <ToggleButtonGroup
        value={sortDirection}
        exclusive
        onChange={(e, value) => value && dispatch(setSortDirection(value))}
        size="small"
      >
        <ToggleButton value="asc">
          Ascending
        </ToggleButton>
        <ToggleButton value="desc">
          Descending
        </ToggleButton>
      </ToggleButtonGroup>
    </Box>
  );
};

export default FilterSort;