// src/components/TaskForm.jsx
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import {
  Box,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Paper,
} from '@mui/material';
import { addTask, editTask } from '../features/slices/taskSlice';

const TaskForm = ({ task, onClose }) => {
  const dispatch = useDispatch();
  const [formData, setFormData] = useState({
    title: task?.title || '',
    description: task?.description || '',
    priority: task?.priority || 1,
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (task) {
      dispatch(editTask({ ...task, ...formData }));
      onClose();
    } else {
      dispatch(addTask(formData));
      setFormData({ title: '', description: '', priority: 1 });
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <Paper sx={{ p: 2, mb: 2 }}>
      <Box component="form" onSubmit={handleSubmit}>
        <TextField
          fullWidth
          label="Title"
          name="title"
          value={formData.title}
          onChange={handleChange}
          required
          sx={{ mb: 2 }}
        />
        <TextField
          fullWidth
          label="Description"
          name="description"
          value={formData.description}
          onChange={handleChange}
          multiline
          rows={2}
          sx={{ mb: 2 }}
        />
        <FormControl fullWidth sx={{ mb: 2 }}>
          <InputLabel>Priority</InputLabel>
          <Select
            name="priority"
            value={formData.priority}
            onChange={handleChange}
            label="Priority"
          >
            <MenuItem value={1}>Low</MenuItem>
            <MenuItem value={2}>Medium</MenuItem>
            <MenuItem value={3}>High</MenuItem>
          </Select>
        </FormControl>
        <Box display="flex" gap={1}>
          <Button type="submit" variant="contained" color="primary">
            {task ? 'Update Task' : 'Add Task'}
          </Button>
          {task && (
            <Button variant="outlined" onClick={onClose}>
              Cancel
            </Button>
          )}
        </Box>
      </Box>
    </Paper>
  );
};

export default TaskForm;