// src/components/TaskList.jsx
import React from 'react';
import { useSelector } from 'react-redux';
import { DragDropContext, Droppable } from 'react-beautiful-dnd';
import { Box, Container } from '@mui/material';
import TaskItem from './TaskItem';
import { useDispatch } from 'react-redux';
import { reorderTasks } from '../features/slices/taskSlice';

const TaskList = () => {
  const dispatch = useDispatch();
  const { tasks, filter, sortBy, sortDirection } = useSelector((state) => state.tasks);

  const filteredTasks = tasks.filter(task => {
    if (filter === 'active') return !task.completed;
    if (filter === 'completed') return task.completed;
    return true;
  });

  const sortedTasks = [...filteredTasks].sort((a, b) => {
    if (sortBy === 'date') {
      return sortDirection === 'asc'
        ? new Date(a.createdAt) - new Date(b.createdAt)
        : new Date(b.createdAt) - new Date(a.createdAt);
    }
    return sortDirection === 'asc'
      ? a.priority - b.priority
      : b.priority - a.priority;
  });

  const onDragEnd = (result) => {
    if (!result.destination) return;

    const items = Array.from(sortedTasks);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    dispatch(reorderTasks(items));
  };

  return (
    <Container maxWidth="md">
      <DragDropContext onDragEnd={onDragEnd}>
        <Droppable droppableId="tasks">
          {(provided) => (
            <Box
              {...provided.droppableProps}
              ref={provided.innerRef}
              sx={{ mt: 2 }}
            >
              {sortedTasks.map((task, index) => (
                <TaskItem key={task.id} task={task} index={index} />
              ))}
              {provided.placeholder}
            </Box>
          )}
        </Droppable>
      </DragDropContext>
    </Container>
  );
};

export default TaskList;