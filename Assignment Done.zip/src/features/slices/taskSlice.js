// src/features/slices/taskSlice.js
import { createSlice } from '@reduxjs/toolkit';
import { loadState, saveState } from '../../utils/localStorage';

const initialState = loadState() || {
  tasks: [],
  filter: 'all', // all, active, completed
  sortBy: 'date', // date, priority
  sortDirection: 'asc'
};

const taskSlice = createSlice({
  name: 'tasks',
  initialState,
  reducers: {
    addTask: (state, action) => {
      state.tasks.push({
        id: Date.now(),
        title: action.payload.title,
        description: action.payload.description,
        priority: action.payload.priority,
        completed: false,
        createdAt: new Date().toISOString(),
      });
      saveState(state);
    },
    editTask: (state, action) => {
      const task = state.tasks.find(task => task.id === action.payload.id);
      if (task) {
        Object.assign(task, action.payload);
        saveState(state);
      }
    },
    deleteTask: (state, action) => {
      state.tasks = state.tasks.filter(task => task.id !== action.payload);
      saveState(state);
    },
    toggleComplete: (state, action) => {
      const task = state.tasks.find(task => task.id === action.payload);
      if (task) {
        task.completed = !task.completed;
        saveState(state);
      }
    },
    reorderTasks: (state, action) => {
      state.tasks = action.payload;
      saveState(state);
    },
    setFilter: (state, action) => {
      state.filter = action.payload;
    },
    setSortBy: (state, action) => {
      state.sortBy = action.payload;
    },
    setSortDirection: (state, action) => {
      state.sortDirection = action.payload;
    }
  },
});

export const {
  addTask,
  editTask,
  deleteTask,
  toggleComplete,
  reorderTasks,
  setFilter,
  setSortBy,
  setSortDirection
} = taskSlice.actions;

export default taskSlice.reducer;